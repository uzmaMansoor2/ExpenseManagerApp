﻿using System;
using System.Collections.Generic;
using System.Text;
using ReceiptServiceReference;

namespace ExpenseManager.Model
{
    public class ReceiptService
    {
        ReceiptServiceClient receiptClient;

        public ReceiptService()
        {
            receiptClient = new ReceiptServiceClient(ReceiptServiceClient.EndpointConfiguration.BasicHttpBinding_IReceiptService);
        }

        public string addReceipt(ReceiptVO receipt)
        {
            return receiptClient.addReceipt(receipt);
        }

        public List<ReceiptVO> getAllReceipt(int customerID)
        {
            return receiptClient.getAllReceipt(customerID);
        }

        public string updateReceipt(ReceiptVO r, string newTagName)
        {
            return receiptClient.updateReceipt(r, newTagName);
        }

        
        public string deleteReceipt(int receiptID)
        {
            return receiptClient.deleteReceipt(receiptID);
        }

        public string addTag(TagVO t)
        {
            return receiptClient.addTag(t);
        }

        
        public List<TagVO> getAllTags(int customerID)
        {
            return receiptClient.getAllTags(customerID);
        }


        public string deleteTag(string tagName)
        {
            return receiptClient.deleteTag(tagName);
        }


    }
}
