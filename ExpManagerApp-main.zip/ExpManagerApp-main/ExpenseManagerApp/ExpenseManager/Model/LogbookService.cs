﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VehicleLogbookServiceReference;
using Xamarin.Forms.Internals;

namespace ExpenseManager.Model
{
    public class LogbookService
    {
        LogBookServiceClient logbookClient;

        public LogbookService()
        {
            logbookClient = new LogBookServiceClient(LogBookServiceClient.EndpointConfiguration.BasicHttpBinding_ILogBookService);
        }

        // VEHICLE METHODS-----------------

        // This method takes a vehicle object.
        // The service is invoked and the vehicle is passed as a parameter.
        // The vehicle object is inserted into the database through the remote service.
        public string addVehicle(VehicleVO v)
        {

            return logbookClient.addVehilce(v); 
        }

        // this method takes a vehicle object.
        // The service is invoked and the vehicle is passed as a parameter.
        // The vehicle object is updated into the database through the remote service.
        public string updateVehicle(VehicleVO v)
        {
            return  logbookClient.updateVehicle(v);            
        }

        public string deleteVehicle(int vehicleID)
        {
            return logbookClient.deleteVehicle(vehicleID);
        }

        public List<VehicleVO> getAllVehicles(int customerID)
        {            
            return logbookClient.getAllVehilces(customerID);            
        }

        public void updateOdometer(int vehicleID, int newReading)
        {
            logbookClient.updateOdometer(vehicleID, newReading);
        }

        public VehicleVO getVehicle(int vehicleID)
        {
            return logbookClient.getVehilce(vehicleID);
        }

        // TRIP METHODS-----------------

        public string addTrip(TripVO t)
        {
            return logbookClient.addTrip(t);
        }

        public string updateTrip(TripVO t)
        {
            return logbookClient.updateTrip(t);
        }

        public string deleteTrip(int tripID)
        {
            return logbookClient.deletetrip(tripID);
        }

        public List<TripVO> getAllTrips(int customerID)
        {
            return logbookClient.getAllTrips(customerID).ToList();
        }
    }
}
