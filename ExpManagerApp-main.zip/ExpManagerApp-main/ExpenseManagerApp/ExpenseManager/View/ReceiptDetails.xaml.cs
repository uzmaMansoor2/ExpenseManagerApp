﻿using ExpenseManager.ViewModel;
using ReceiptServiceReference;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using System.Net;
using Android.Graphics;
using Android.Util;

namespace ExpenseManager.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ReceiptDetails : ContentPage
    {
        ReceiptViewModel thisViewModel;
        static ReceiptVO r;
        TagVO t;
        string operationOutcome;


        public ReceiptDetails()
        {
            InitializeComponent();
            //thisViewModel = new ReceiptViewModel();
            //BindingContext = thisViewModel.getAllTags(App.CustomerID);
        }

        protected override void OnAppearing()
        {
            //if receipt is an existing receipt
            if(save_update_BtnTollBarItem.Text == "UPDATE")
            {
                //get receipt from binding context
                r = new ReceiptVO();
                r = (ReceiptVO)BindingContext;
                //add receipt to this view model
                thisViewModel = new ReceiptViewModel();
                thisViewModel.Receipt = r;

                //if tag list is not empty
                if ((thisViewModel.getAllTags(App.CustomerID)).Count != 0)
                {
                    //hide empty tag list message
                    emptyTagListLabel.IsVisible = false;

                    //add view model to binding context
                    BindingContext = thisViewModel;
                    // find the binding context receipt object tag in the tag list
                    for (int i = 0; i < thisViewModel.TagList.Count; i++)
                    {
                        if (thisViewModel.TagList[i].tagName == r.Tag_tagName)
                        {
                            //select the tag object in the tag list view
                            tagListView.SelectedItem = thisViewModel.TagList[i];
                        }
                    }
                }
                else
                {
                    //show empty tag list message
                    emptyTagListLabel.IsVisible = true;
                }

            }
            //if receipt is a new receipt
            else
            {
                Image img = (Image)BindingContext;
                thisViewModel = new ReceiptViewModel();
                if (img != null)
                {
                    receiptPhoto.Source = img.Source;
                }
                

                //if tag list is not empty
                if ((thisViewModel.getAllTags(App.CustomerID)).Count != 0)
                {
                    
                    //hide empty tag list message
                    emptyTagListLabel.IsVisible = false;

                    //add view model to binding context
                    BindingContext = thisViewModel;                    
                }
            }
        }

        // this method will either save or update a certain receipt.
        // tollbar items do not have visible property so for that reason
        // whenever the name of the button is 'update' the method will update existing item.
        // otherwise a new item will be inserted into DB.

        // if the operation is 'update', the vehicle object is retrieved from the binding context
        private async void update_save_Receipt_Clicked(object sender, EventArgs e)
        {
            if (save_update_BtnTollBarItem.Text == "UPDATE")
            {
                var newTag = (TagVO)tagListView.SelectedItem;
                operationOutcome = thisViewModel.updateReceipt(r, newTag.tagName);
                _ = DisplayAlert("INFO", operationOutcome, "OK");

                save_update_BtnTollBarItem.Text = "Save";
                deleteReceiptBtn.IsVisible = false;
                await Navigation.PopToRootAsync();
            }
            else
            {
                if(tagListView.SelectedItem != null)
                {
                    r = new ReceiptVO();
                    r.Customer_customerID = App.CustomerID;
                    r.ABN = ABNInputField.Text;
                    r.date = DateInputField.Date;
                    r.image = ConvertStreamtoByteAsync((ImageSource)receiptPhoto.Source);
                    r.merchant = MerchantInputField.Text;
                    t = new TagVO();
                    t = (TagVO)tagListView.SelectedItem;
                    r.Tag_tagName = t.tagName;
                    r.tax = double.Parse(TaxInputField.Text);
                    r.total = double.Parse(TotalInputField.Text);

                    operationOutcome = thisViewModel.addReceipt(r);

                    _ = DisplayAlert("INFO", operationOutcome, "OK");

                    await Navigation.PopToRootAsync();
                }
                else
                {
                    operationOutcome = "Please selecta Tag. Cannot insert a Receipt without a tag.";
                    _ = DisplayAlert("INFO", operationOutcome, "OK");
                }               
            }
            
        }

        private async void deleteReceiptBtn_Clicked(object sender, EventArgs e)
        {
            operationOutcome = thisViewModel.deleteReceipt(r.receiptID);
            _ = DisplayAlert("INFO", operationOutcome, "OK");

            deleteReceiptBtn.IsVisible = false;
            await Navigation.PopToRootAsync();
        }

        private void tagListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            
        }

        //this method enables visibility for the tag controls.
        //once controls are visible user is able to insert a tag name and add a new tag
        private void newTagBtn_Clicked(object sender, EventArgs e)
        {
            addTagLayout.IsVisible = true;
        }

        private void deleteTagBtn_Clicked(object sender, EventArgs e)
        {
            if(tagListView.SelectedItem != null)
            {
                t = new TagVO();
                t = (TagVO)tagListView.SelectedItem;
                operationOutcome = thisViewModel.deleteTag(t.tagName);
                tagListView.SelectedItem = null;
                //setting updated wiew model to the tag list item source
                tagListView.ItemsSource = thisViewModel.getAllTags(App.CustomerID);
                
            }
            else
            {
                operationOutcome = "Please selecta Tag to delete.";
            }

            _ = DisplayAlert("INFO", operationOutcome, "OK");
        }

        private void addTagBtn_Clicked(object sender, EventArgs e)
        {
            if (tagNameInputField.Text != null || tagNameInputField.Text != "" )
            {
                t = new TagVO();
                t.tagName = tagNameInputField.Text;
                t.Customer_customerID = App.CustomerID;
                operationOutcome = thisViewModel.addTag(t);
                addTagLayout.IsVisible = false;
                //setting updated wiew model to the tag list item source
                tagListView.ItemsSource = thisViewModel.getAllTags(App.CustomerID);
                tagNameInputField.Text = "";
            }
            else
            {
                operationOutcome = "Please insert a tag name.";
            }

            _ = DisplayAlert("INFO", operationOutcome, "OK");
        }


        private  byte[] ConvertStreamtoByteAsync(ImageSource imageSource)
        {
            try
            {
                byte[] buffer = new byte[16 * 1024];

                if (imageSource is FileImageSource)
                {
                    FileImageSource objFileImageSource = (FileImageSource)imageSource;
                    string strFileName = objFileImageSource.File;

                    var webClient = new WebClient();
                    buffer =  webClient.DownloadData(new Uri(strFileName));
                    return buffer;
                }
            }
            catch (Exception ex)
            {

            }
            return null;
        }

        //public Bitmap Base64ToBitmap(String base64String)
        //{
        //    byte[] imageAsBytes = Base64.Decode(base64String, Base64Flags.Default);
        //    return BitmapFactory.DecodeByteArray(imageAsBytes, 0, imageAsBytes.Length);
        //}

        //Task<Bitmap> GetBitmap(Xamarin.Forms.Image image)
        //{
        //    var handler = new ImageLoaderSourceHandler();
        //    return handler.LoadImageAsync(image.Source);
        //}
    }
}