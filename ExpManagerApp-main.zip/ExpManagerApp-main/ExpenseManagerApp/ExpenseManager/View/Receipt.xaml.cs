﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExpenseManager.Model;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;
using ExpenseManager.ViewModel;
using ReceiptServiceReference;

namespace ExpenseManager.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Receipt : ContentPage
    {
        ReceiptViewModel thisViewModel;
        public Receipt()
        {
            InitializeComponent();
            thisViewModel = new ReceiptViewModel();

            if ((thisViewModel.loadReceipts(App.CustomerID)).Count != 0)
            {
                BindingContext = thisViewModel;
                emptyReceiptListLabel.IsVisible = false;
            }
            else
            {
                emptyReceiptListLabel.IsVisible = true;
            }
        }

        protected override void OnAppearing()
        {
            thisViewModel = new ReceiptViewModel();
            if ((thisViewModel.loadReceipts(App.CustomerID)).Count != 0)
            {
                BindingContext = thisViewModel;
                emptyReceiptListLabel.IsVisible = false;
            }
            else
            {
                emptyReceiptListLabel.IsVisible = true;
            }
        }

        // Receipt List Item Selected Event
        private async void receiptListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {

            ReceiptVO r = new ReceiptVO();
            r = (ReceiptVO)receiptListView.SelectedItem;
            var receiptDetailsPage = new ReceiptDetails();
            receiptDetailsPage.BindingContext = r;
            receiptDetailsPage.save_update_BtnTollBarItem.Text = "UPDATE";
            receiptDetailsPage.deleteReceiptBtn.IsVisible = true;
            await Navigation.PushAsync(receiptDetailsPage);
        }

        // Add manual Receipt clicke event
        private async void addManualReceipt_Clicked(object sender, EventArgs e)
        {
            var receiptDetailsPage = new ReceiptDetails();
            receiptDetailsPage.deleteReceiptBtn.IsVisible = false;
            await Navigation.PushAsync(receiptDetailsPage);
        }

       
    }
}