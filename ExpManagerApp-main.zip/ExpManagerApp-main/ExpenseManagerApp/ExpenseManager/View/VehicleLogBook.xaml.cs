﻿using ExpenseManager.Model;
using ExpenseManager.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using VehicleLogbookServiceReference;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ExpenseManager.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VehicleLogbook : ContentPage
    {
        LogbookViewModel thisViewModel;

        public VehicleLogbook()
        {
            InitializeComponent();
            thisViewModel = new LogbookViewModel();
            
            if ((thisViewModel.loadVeahicles(App.CustomerID)).Count != 0)
            {
                BindingContext = thisViewModel;
                vehicleListView.SelectedItem = thisViewModel.VehicleList[0];
                emptyVehicleListLabel.IsVisible = false;
            }
            else
            {
                emptyVehicleListLabel.IsVisible = true;
            }
        }

        protected override void OnAppearing()
        {
            thisViewModel = new LogbookViewModel();
            if ((thisViewModel.loadVeahicles(App.CustomerID)).Count != 0)
            {
                BindingContext = thisViewModel;
                vehicleListView.SelectedItem = thisViewModel.VehicleList[0];
                emptyVehicleListLabel.IsVisible = false;
            }
            else
            {
                emptyVehicleListLabel.IsVisible = true;
                makeTxt.Text = "";
                modelTxt.Text = "";
                numPlateTxt.Text = "";
            }
        }


        // this event gets called everytime the vehicl selection changes
        private void vehicleListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            VehicleVO v = new VehicleVO();
            v = (VehicleVO)vehicleListView.SelectedItem;

            makeTxt.Text = v.make;
            modelTxt.Text = v.model;
            numPlateTxt.Text = v.licencePlate;

            tripListView.ItemsSource = v.Trips;
        }

        //This event hides/shows the vehicle list coming down from the toolbar
        private void selectVehicleBtn_Clicked(object sender, EventArgs e)
        {
            if (vehicleListOuterContainer.IsVisible == true)
            {
                vehicleListOuterContainer.IsVisible = false;
                selectVehicleBtn.Text = "SELECT VEHICLE ﹀";
            }                
            else if (vehicleListOuterContainer.IsVisible == false)
            {
                vehicleListOuterContainer.IsVisible = true;
                selectVehicleBtn.Text = "SELECT VEHICLE ︿";
            }
                 
        }

        //Add vehicle tool bar item clicked
        private async void addVehicle_Clicked(object sender, EventArgs e)
        {
            var vehicleDetailsPage = new VehicleDetails();
            vehicleDetailsPage.OdometerInputField.IsReadOnly = false;
            await Navigation.PushAsync(vehicleDetailsPage);
        }

        private async void editVehiclebtn_Clicked(object sender, EventArgs e)
        {
            VehicleVO v = new VehicleVO();
            v = (VehicleVO)vehicleListView.SelectedItem;            
            var vehicleDetailsPage = new VehicleDetails();
            vehicleDetailsPage.BindingContext = v;
            vehicleDetailsPage.save_update_BtnTollBarItem.Text = "Update";
            vehicleDetailsPage.deleteVehicleBtn.IsVisible = true;
            vehicleDetailsPage.OdometerInputField.IsReadOnly = true;
            await Navigation.PushAsync(vehicleDetailsPage, true);
        }

        //This method gets fired everytime a trip gets selected from the list
        //The method extracts the trip object and send it to the trip detaails page through its binding context
        private async void tripListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            TripVO t = new TripVO();
            t = (TripVO)tripListView.SelectedItem;
            var tripDetailsPage = new TripDetails();
            tripDetailsPage.BindingContext = t;
            tripDetailsPage.save_update_BtnTollBarItem.Text = "Update";
            tripDetailsPage.deleteTripBtn.IsVisible = true;

            await Navigation.PushAsync(tripDetailsPage);
        }

        private async void insertManualTripBtn_Clicked(object sender, EventArgs e)
        {
            var tripDetailsPage = new TripDetails();
            tripDetailsPage.deleteTripBtn.IsVisible = false;
            await Navigation.PushAsync(tripDetailsPage);
        }
    }
}