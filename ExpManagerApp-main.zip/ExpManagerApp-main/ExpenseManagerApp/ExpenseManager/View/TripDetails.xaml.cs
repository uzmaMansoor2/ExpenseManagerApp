﻿using ExpenseManager.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using VehicleLogbookServiceReference;
using Xamarin.Forms;
using Xamarin.Forms.Internals;
using Xamarin.Forms.Xaml;

namespace ExpenseManager.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class TripDetails : ContentPage
    {
        LogbookViewModel thisViewModel;

        TripVO t;
        VehicleVO v;
        string operationOutcome;
        int previousDistanceTravelled;
        public static int count = 0;
        public TripDetails()
        {
            InitializeComponent();
            thisViewModel = new LogbookViewModel();

            //unsubscribing from textchanged event
            //the textchanged event fires up before the on appearing event.
            // some of the values before the on appearing event are still null when the text changed event gets fired
            distanceTravelledInputField.TextChanged -= distanceTravelledInputField_TextChanged;
        }

        protected override void OnAppearing()
        {
            vehicleListView.ItemsSource = thisViewModel.loadVeahicles(App.CustomerID);
            t = (TripVO)BindingContext;

            if (t != null)
            {
                previousDistanceTravelled = t.distanceTravelled;
                vehicleListView.SelectedItem = thisViewModel.VehicleList.FirstOrDefault(v => v.vehicleID == t.Vehicle_vehicleID);
                v = (VehicleVO)vehicleListView.SelectedItem;                            
            }            

            //subscribing to the textchanged event.
            //at this point all of the values have been loaded
            distanceTravelledInputField.TextChanged += distanceTravelledInputField_TextChanged;

            //resetting count 
            count = 0;
        }

        //This method performs either the save or update operation based on the button name.
        private async void save_update_Btn_Clicked(object sender, EventArgs e)
        {
            
            v = (VehicleVO)vehicleListView.SelectedItem;
            //trip object passed through the binding context
            t = (TripVO)BindingContext;

            //if button text is UPDATE
            if (save_update_BtnTollBarItem.Text == "Update")
            {
                //needs validation***************************
                t.Vehicle_vehicleID = v.vehicleID;
                operationOutcome = thisViewModel.updateTrip(t);
                
                _ = DisplayAlert("INFO", operationOutcome, "OK");

                //reset button text to SAVE
                save_update_BtnTollBarItem.Text = "Save";
            }
            //if button text is SAVE
            else
            {
                //needs validation***************

                //create new trip object
                t = new TripVO();
                //collect data for the new trip object
                t.Vehicle_vehicleID = v.vehicleID;
                t.startDate = startDateInputField.Date.Date;
                t.endDate = endDateInputField.Date.Date;
                t.distanceTravelled= int.Parse(distanceTravelledInputField.Text);
                t.start = startLocationInputField.Text;
                t.finish = endLocationInputField.Text;
                t.description = "no Description avaiable yet";
                //inserting new trip
                operationOutcome = thisViewModel.addTrip(t);

                _ = DisplayAlert("INFO", operationOutcome, "OK");
            }
            await Navigation.PopToRootAsync();
        }


        private async void deleteTripBtn_Clicked(object sender, EventArgs e)
        {
            t = new TripVO();
            t = (TripVO)BindingContext;
            operationOutcome = thisViewModel.deleteTrip(t.tripID);
            _ = DisplayAlert("INFO", operationOutcome, "OK");

            await Navigation.PopToRootAsync();
        }


        private void vehicleListView_ItemSelected(object sender, SelectedItemChangedEventArgs e)
        {
            v = (VehicleVO)vehicleListView.SelectedItem;
            //odometerInputField.Text = v.Odometer.ToString();
            t = (TripVO)BindingContext;

            if(t == null)
            {
                odometerInputField.Text = v.odometer.ToString();
                if(distanceTravelledInputField.Text != null)
                {
                    //recalculate with the new distance travelled value in real time
                    odometerAdditionInputField.Text = (int.Parse(odometerInputField.Text) + int.Parse(distanceTravelledInputField.Text)).ToString();
                }                
            }
            else
            {
                //if the selected vehicle is the same as before
                if (distanceTravelledInputField.Text != null && t.Vehicle_vehicleID == v.vehicleID)
                {
                    //'count', refers to the number of selection of the same vehicle after an other vehicle has been selected 
                    // if the original trip vehicle has been selected again, the count will be >0
                    if (count == 0)
                    {
                        //resetting the previous odometer reading when the same vehicle has been selected
                        //this if statement is only accessible the first time.
                        //once the selected vehicle has changed and selected again, this if statement won't be accessible
                        v.odometer = v.odometer - previousDistanceTravelled;
                        count++;
                    }

                    //odometer reading before the update
                    odometerInputField.Text = v.odometer.ToString();
                    //resetting the new odometer reading
                    odometerAdditionInputField.Text = (v.odometer + previousDistanceTravelled).ToString();
                }
                //if the selected vehicle is different than the previous one
                else if (distanceTravelledInputField.Text != null && t.Vehicle_vehicleID != v.vehicleID)
                {
                    odometerInputField.Text = v.odometer.ToString();
                    //calculate new odometer reading
                    odometerAdditionInputField.Text = (v.odometer + previousDistanceTravelled).ToString();
                }
            }
        }

        //this event controls the new odometer reading in real time.
        //it is based on the distance travelled and the current odometer reading
        private void distanceTravelledInputField_TextChanged(object sender, TextChangedEventArgs e)
        {

            if(vehicleListView.SelectedItem != null)
            {
                odometerAdditionInputField.Text = "";

                if (distanceTravelledInputField.Text != "")
                {
                    //recalculate with the new distance travelled value in real time
                    odometerAdditionInputField.Text = (int.Parse(odometerInputField.Text) + int.Parse(distanceTravelledInputField.Text)).ToString();
                }
            }
            else
            {
                _ = DisplayAlert("INFO", "Select a Vehicle First.", "OK");
            }

            if (distanceTravelledInputField.Text.Contains("."))
            {
                _ = DisplayAlert("INFO", "Distance travelled cannot be a decimal number.", "OK");
            }
            
        }

        
    }
}