﻿using ExpenseManager.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VehicleLogbookServiceReference;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace ExpenseManager.View
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class VehicleDetails : ContentPage
    {
        LogbookViewModel thisViewModel;
        VehicleVO v;
        string operationOutcome;

        public VehicleDetails()
        {
            InitializeComponent();
            thisViewModel = new LogbookViewModel();
            BindingContext = thisViewModel;            
        }

        // this method will either save or update a certain vehicle.
        // tollbar items do not have visible property so for that reason
        // whenever the name of the button is 'update' the method will update existing item.
        // otherwie a new item will be inserted into DB.

        // if the operation is 'update', the vehicle object is retrieved from the binding context
        private async void update_save_Vehicle_Clicked(object sender, EventArgs e)
        {
            if (save_update_BtnTollBarItem.Text == "Update")
            {
                v = new VehicleVO();
                v = (VehicleVO)BindingContext;
                operationOutcome = thisViewModel.updateVehicle(v);
                _ = DisplayAlert("INFO", operationOutcome, "OK");

                save_update_BtnTollBarItem.Text = "Save";
                deleteVehicleBtn.IsVisible = false;
            }
            else
            {
                v = new VehicleVO();
                v.Customer_customerID = App.CustomerID;
                v.make = MakeInputField.Text;
                v.model = ModelInputField.Text;
                v.odometer = int.Parse(OdometerInputField.Text);
                v.engineCpacity = int.Parse(EngineCapacityInputField.Text);
                v.licencePlate = LicencePlateInputField.Text;
                v.year = short.Parse(YearInputField.Text);

                operationOutcome = thisViewModel.addVehicle(v);

                _ = DisplayAlert("INFO", operationOutcome, "OK");
            }


            await Navigation.PopToRootAsync();
        }


        // this method will delete a certain vehicle based on the vehicle ID.
        // the vehicle object id is retrieved from the binding context
        private async void deleteVehicleBtn_Clicked(object sender, EventArgs e)
        {
            v = new VehicleVO();
            v = (VehicleVO)BindingContext;
            operationOutcome = thisViewModel.deleteVehicle(v.vehicleID);
            _ = DisplayAlert("INFO", operationOutcome, "OK");

            deleteVehicleBtn.IsVisible = false;
            await Navigation.PopToRootAsync();
        }

        
    }
}