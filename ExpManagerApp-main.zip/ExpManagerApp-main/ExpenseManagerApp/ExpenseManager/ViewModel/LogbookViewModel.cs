﻿using ExpenseManager.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Text;
using VehicleLogbookServiceReference;

namespace ExpenseManager.ViewModel
{
    public class LogbookViewModel 
    {
        private LogbookService service { get; }

        private ObservableCollection<TripVO> tripList { get; set; }
        public ObservableCollection<TripVO> TripList
        {
            get { return tripList; }
            set
            {
                tripList = value;
            }
        }

        private ObservableCollection<VehicleVO> vehicleList { get; set; }
        public ObservableCollection<VehicleVO> VehicleList
        {
            get { return vehicleList; }
            set
            {
                vehicleList = value;
            }
        }

        public LogbookViewModel()
        {
            service = new LogbookService();
        }



        // VEHICLE METHODS-----------------
        public string addVehicle(VehicleVO v)
        {
           return service.addVehicle(v);
        }

        public string updateVehicle(VehicleVO v)
        {
            return service.updateVehicle(v);
        }

        public string deleteVehicle(int vehicleID)
        {
            return service.deleteVehicle(vehicleID);
        }

        public ObservableCollection<VehicleVO> loadVeahicles(int CustomerID)
        {
            VehicleList = new ObservableCollection<VehicleVO>(service.getAllVehicles(CustomerID));
            return VehicleList;
        }

        public void updateOdometer (int vehicleID, int newReading)
        {
            service.updateOdometer(vehicleID, newReading);
        }

        public VehicleVO getVehicle(int vehicleID)
        {
            return service.getVehicle(vehicleID);
        }

        // TRIP METHODS-----------------

        public string addTrip(TripVO t)
        {
            return service.addTrip(t);
        }

        public string updateTrip(TripVO t)
        {
            return service.updateTrip(t);
        }

        public string deleteTrip(int tripID)
        {
            return service.deleteTrip(tripID);
        }

        public ObservableCollection<TripVO> getTrips(int VehicleID)
        {
            TripList = new ObservableCollection<TripVO>(service.getAllTrips(VehicleID));
            return TripList;
        }
    }
}
