﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Android.Media;
using ExpenseManager.Model;
using ReceiptServiceReference;

namespace ExpenseManager.ViewModel
{
    public class ReceiptViewModel
    {
        private ReceiptService service {get;}

        private ObservableCollection<ReceiptVO> receiptList { get; set; }
        public ObservableCollection<ReceiptVO> ReceiptList
        {
            get { return receiptList; }
            set
            {
                receiptList = value;
            }
        }

        private ReceiptVO receipt{ get; set; }
        public ReceiptVO Receipt
        {
            get { return receipt; }
            set
            {
                receipt = value;
            }
        }


        private Image image { get; set; }
        public Image Image
        {
            get { return image; }
            set
            {
                image = value;
            }
        }

        private ObservableCollection<TagVO> tagList { get; set; }
        public ObservableCollection<TagVO> TagList
        {
            get { return tagList; }
            set
            {
                tagList = value;
            }
        }

        public ReceiptViewModel()
        {
            service = new ReceiptService();
        }

        public string addReceipt(ReceiptVO receipt)
        {
            return service.addReceipt(receipt);
        }

        public ObservableCollection<ReceiptVO> loadReceipts(int customerID)
        {
            ReceiptList = new ObservableCollection<ReceiptVO>(service.getAllReceipt(customerID));
            return ReceiptList;
        }

        public string updateReceipt(ReceiptVO r, string newTagName)
        {
            return service.updateReceipt(r, newTagName);
        }


        public string deleteReceipt(int receiptID)
        {
            return service.deleteReceipt(receiptID);
        }

        public string addTag(TagVO t)
        {
            return service.addTag(t);
        }


        public ObservableCollection<TagVO> getAllTags(int customerID)
        {
            TagList = new ObservableCollection<TagVO>(service.getAllTags(customerID));
            return TagList; 
        }


        public string deleteTag(string tagName)
        {
            return service.deleteTag(tagName);
        }
    }
}
